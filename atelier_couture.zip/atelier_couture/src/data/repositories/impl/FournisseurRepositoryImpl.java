package data.repositories.impl;

import data.entites.Fournisseur;
import data.repositories.FournisseurRepository;

public class FournisseurRepositoryImpl extends RepositoryImpl<Fournisseur> implements FournisseurRepository {
}
