package data.repositories.impl;

import data.entites.Vente;
import data.repositories.VenteRepository;

public class VenteRepositoryImpl extends RepositoryImpl<Vente>  implements VenteRepository {
}
