package data.repositories.impl;

import data.entites.Client;
import data.repositories.ClientRepository;

public class ClientRepositoryImpl extends RepositoryImpl<Client> implements ClientRepository {
}
