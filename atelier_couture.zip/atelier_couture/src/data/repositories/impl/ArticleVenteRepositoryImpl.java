package data.repositories.impl;

import data.entites.ArticleVente;
import data.repositories.ArticleVenteRepository;

import java.util.List;

public class ArticleVenteRepositoryImpl extends RepositoryImpl<ArticleVente> implements ArticleVenteRepository {

}
