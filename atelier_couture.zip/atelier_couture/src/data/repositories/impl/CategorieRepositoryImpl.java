package data.repositories.impl;

import data.entites.Categorie;
import data.repositories.CategorieRepository;

public class CategorieRepositoryImpl extends RepositoryImpl <Categorie> implements CategorieRepository {

}
