package data.repositories.impl;

import data.entites.Approvisionnement;
import data.repositories.ApprovisionnementRepository;

public class ApprovisionnementRepositoryImpl extends RepositoryImpl<Approvisionnement> implements ApprovisionnementRepository {
}
