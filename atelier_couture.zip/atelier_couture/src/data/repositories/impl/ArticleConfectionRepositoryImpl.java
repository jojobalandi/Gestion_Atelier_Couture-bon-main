package data.repositories.impl;

import data.entites.ArticleConfection;
import data.repositories.ArticleConfectionRepository;

import java.util.List;

public class ArticleConfectionRepositoryImpl extends RepositoryImpl<ArticleConfection> implements ArticleConfectionRepository {

}
