package data.repositories;

import data.entites.Approvisionnement;

public interface ApprovisionnementRepository extends Repository<Approvisionnement> {
}
