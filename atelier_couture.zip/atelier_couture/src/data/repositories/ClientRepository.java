package data.repositories;

import data.entites.Client;

public interface ClientRepository extends Repository<Client>{
}
