package data.repositories;

import data.entites.Production;

public interface ProductionRepository extends Repository<Production>{
}
