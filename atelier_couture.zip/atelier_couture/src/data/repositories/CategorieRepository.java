package data.repositories;

import data.entites.Categorie;

public interface CategorieRepository extends Repository<Categorie> {
}
