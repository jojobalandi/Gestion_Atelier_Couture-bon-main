package data.repositories;

import data.entites.ArticleConfection;

public interface ArticleConfectionRepository extends Repository<ArticleConfection> {
}
