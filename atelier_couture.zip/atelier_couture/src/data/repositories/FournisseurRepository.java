package data.repositories;

import data.entites.Fournisseur;

public interface FournisseurRepository extends Repository<Fournisseur> {
}
