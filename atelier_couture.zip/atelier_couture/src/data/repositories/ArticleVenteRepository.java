package data.repositories;

import data.entites.ArticleVente;

public interface ArticleVenteRepository extends Repository<ArticleVente>{

}
