package data.repositories;

import data.entites.Vente;

public interface VenteRepository extends Repository<Vente> {
}
