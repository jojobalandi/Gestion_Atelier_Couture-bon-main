package data.enums;

public enum Role {
    VENDEUR,
    GESTIONNAIRE,
    RESPONSABLE_STOCK,
    RESPONSABLE_VENTE;
}
